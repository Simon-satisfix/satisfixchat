import { readFile } from 'xlsx';
import { db } from '../src/config/firebase';
import { collection, addDoc, writeBatch } from 'firebase/firestore';
import { Repair } from '../src/types';

const BATCH_SIZE = 500; // Nombre maximum de documents par lot

async function importRepairsFromExcel(filePath: string) {
  try {
    // Lire le fichier Excel
    const workbook = readFile(filePath);
    const worksheet = workbook.Sheets[workbook.SheetNames[0]];
    const repairs = readFile.utils.sheet_to_json(worksheet);

    console.log(`Trouvé ${repairs.length} réparations à importer`);

    // Créer des lots pour l'import
    const batches = [];
    let currentBatch = writeBatch(db);
    let operationCount = 0;
    let totalImported = 0;

    for (const repair of repairs) {
      // Convertir les données Excel en format Repair
      const repairData: Repair = {
        applianceType: repair.applianceType,
        brand: repair.brand,
        model: repair.model,
        problemDescription: repair.problemDescription,
        solution: repair.solution || '',
        diagnosis: repair.diagnosis ? repair.diagnosis.split(',') : [],
        clientName: repair.clientName,
        technicianEmail: repair.technicianEmail,
        date: repair.date ? new Date(repair.date).toISOString() : new Date().toISOString(),
        status: 'completed',
        success: repair.success === 'true' || repair.success === true,
        aiConversation: [],
        lastUpdated: new Date().toISOString()
      };

      const docRef = doc(collection(db, 'repairs'));
      currentBatch.set(docRef, repairData);
      operationCount++;
      totalImported++;

      // Si le lot atteint la taille maximale, le commiter et en créer un nouveau
      if (operationCount === BATCH_SIZE) {
        batches.push(currentBatch);
        currentBatch = writeBatch(db);
        operationCount = 0;
        console.log(`Préparé ${totalImported} réparations...`);
      }
    }

    // Ajouter le dernier lot s'il contient des opérations
    if (operationCount > 0) {
      batches.push(currentBatch);
    }

    // Commiter tous les lots
    console.log('Début de l\'import...');
    for (let i = 0; i < batches.length; i++) {
      await batches[i].commit();
      console.log(`Lot ${i + 1}/${batches.length} importé`);
    }

    console.log(`Import terminé! ${totalImported} réparations importées avec succès.`);
  } catch (error) {
    console.error('Erreur lors de l\'import:', error);
  }
}