import { importRepairsFromExcel } from './importRepairs';

// Exemple d'utilisation
const EXCEL_FILE_PATH = './repairs-history.xlsx';
importRepairsFromExcel(EXCEL_FILE_PATH);