import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { ChatMessage, Repair, User } from '../types';

interface AIConfig {
  apiKey: string;
  systemPrompt: string;
}

interface AppState {
  repairs: Repair[];
  chatHistory: ChatMessage[];
  user: User | null;
  isOffline: boolean;
  currentRepair: Repair | null;
  aiConfig: AIConfig | null;
  addRepair: (repair: Repair) => void;
  addChatMessage: (message: ChatMessage) => void;
  clearChatHistory: () => void;
  setUser: (user: User | null) => void;
  setOffline: (status: boolean) => void;
  setCurrentRepair: (repair: Repair | null) => void;
  setAIConfig: (config: AIConfig) => void;
}

export const useStore = create<AppState>()(
  persist(
    (set) => ({
      repairs: [],
      chatHistory: [],
      user: null,
      isOffline: false,
      currentRepair: null,
      aiConfig: null,
      addRepair: (repair) =>
        set((state) => ({
          repairs: [...state.repairs, repair],
          currentRepair: repair
        })),
      addChatMessage: (message) =>
        set((state) => ({ chatHistory: [...state.chatHistory, message] })),
      clearChatHistory: () => set({ chatHistory: [] }),
      setUser: (user) => set({ user }),
      setOffline: (status) => set({ isOffline: status }),
      setCurrentRepair: (repair) => set({ currentRepair: repair }),
      setAIConfig: (config) => set({ aiConfig: config }),
    }),
    {
      name: 'app-storage',
      partialize: (state) => ({
        user: state.user,
        aiConfig: state.aiConfig,
        repairs: state.repairs,
      }),
    }
  )
);