import { initializeApp } from 'firebase/app';
import { getAuth, connectAuthEmulator } from 'firebase/auth';
import { getFirestore, connectFirestoreEmulator } from 'firebase/firestore';
import { getAnalytics, isSupported } from 'firebase/analytics';

const firebaseConfig = {
  apiKey: "AIzaSyAhIs1XSxnEBY9nerFxu8Xc-1ahhsMG1Os",
  authDomain: "aidealareparation.firebaseapp.com",
  projectId: "aidealareparation",
  storageBucket: "aidealareparation.appspot.com",
  messagingSenderId: "240503897637",
  appId: "1:240503897637:web:1d989f02ec4224a38209cc",
  measurementId: "G-SVK881K6MY"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize services with optimized settings
const auth = getAuth(app);
auth.useDeviceLanguage(); // Use device language for auth UI

const db = getFirestore(app);

// Initialize Analytics only in production
const analytics = import.meta.env.PROD ? 
  await isSupported().then(yes => yes ? getAnalytics(app) : null) : 
  null;

export { app, auth, db, analytics };