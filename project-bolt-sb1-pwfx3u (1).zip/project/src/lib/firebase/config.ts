export const firebaseConfig = {
  apiKey: "AIzaSyAhIs1XSxnEBY9nerFxu8Xc-1ahhsMG1Os",
  authDomain: "aidealareparation.firebaseapp.com",
  projectId: "aidealareparation",
  storageBucket: "aidealareparation.firebasestorage.app",
  messagingSenderId: "240503897637",
  appId: "1:240503897637:web:1d989f02ec4224a38209cc",
  measurementId: "G-SVK881K6MY"
};

export const firestoreSettings = {
  experimentalForceLongPolling: true,
  useFetchStreams: false,
  cacheSizeBytes: 40000000
};