import { getFirestore, initializeFirestore } from 'firebase/firestore';
import { app } from './init';

// Initialize Firestore with optimized settings
const db = initializeFirestore(app, {
  experimentalForceLongPolling: true,
  useFetchStreams: false,
  cacheSizeBytes: 40000000 // 40MB cache size
});

export { db };