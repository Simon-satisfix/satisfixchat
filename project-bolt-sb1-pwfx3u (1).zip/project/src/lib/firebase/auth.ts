import { getAuth, setPersistence, browserLocalPersistence } from 'firebase/auth';
import { app } from './init';

const auth = getAuth(app);

// Enable persistent auth state
setPersistence(auth, browserLocalPersistence)
  .catch((error) => {
    console.error('Error setting auth persistence:', error);
  });

export { auth };