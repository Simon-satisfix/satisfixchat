import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useStore } from '../store/useStore';
import { toast } from 'react-hot-toast';
import { Wrench, Loader } from 'lucide-react';
import { db } from '../lib/firebase';
import { collection, addDoc, serverTimestamp, doc, setDoc } from 'firebase/firestore';
import { useOnlineStatus } from '../hooks/useOnlineStatus';

const BRANDS = [
  'AEG', 'Bosch', 'Brandt', 'Candy', 'Electrolux', 'Fagor', 'Frigidaire',
  'Haier', 'Indesit', 'LG', 'Miele', 'Panasonic', 'Samsung', 'Sharp',
  'Siemens', 'Smeg', 'Whirlpool', 'Zanussi'
].sort();

export function NewRepair() {
  const navigate = useNavigate();
  const { addRepair, setCurrentRepair, user } = useStore();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const isOnline = useOnlineStatus();
  const [formData, setFormData] = useState({
    applianceType: '',
    brand: '',
    model: '',
    problemDescription: '',
    clientName: ''
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isSubmitting) return;

    if (Object.values(formData).some(value => !value.trim())) {
      toast.error('Veuillez remplir tous les champs');
      return;
    }

    if (!user?.email) {
      toast.error('Erreur: Email du technicien non disponible');
      return;
    }

    setIsSubmitting(true);
    const toastId = toast.loading('Création de la réparation...');

    try {
      const repairData = {
        ...formData,
        technicianEmail: user.email,
        diagnosis: [],
        solution: '',
        status: 'pending',
        success: false,
        aiConversation: [],
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
        offlineCreated: !isOnline
      };

      let docRef;
      if (isOnline) {
        docRef = await addDoc(collection(db, 'repairs'), repairData);
      } else {
        // Generate a temporary ID for offline mode
        const tempId = 'temp_' + Date.now();
        docRef = doc(collection(db, 'repairs'), tempId);
        await setDoc(docRef, repairData);
      }

      const repairWithId = {
        ...repairData,
        id: docRef.id,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };

      addRepair(repairWithId);
      setCurrentRepair(repairWithId);

      toast.success(isOnline ? 'Nouvelle réparation créée' : 'Réparation créée en mode hors ligne', { id: toastId });
      navigate('/assistant');
    } catch (error) {
      console.error('Error creating repair:', error);
      toast.error('Erreur lors de la création. Veuillez réessayer.', { id: toastId });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto">
      <div className="flex items-center mb-6">
        <Wrench className="h-8 w-8 text-primary mr-3" />
        <h1 className="text-2xl font-bold text-primary">Nouvelle Réparation</h1>
      </div>
      
      <form onSubmit={handleSubmit} className="space-y-6 bg-white p-6 rounded-lg shadow">
        <div>
          <label className="block text-sm font-medium text-gray-700">
            Nom du Client
          </label>
          <input
            type="text"
            name="clientName"
            value={formData.clientName}
            onChange={handleChange}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-secondary focus:ring-secondary"
            placeholder="Nom complet du client"
            disabled={isSubmitting}
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">
            Type d'Appareil
          </label>
          <select
            name="applianceType"
            value={formData.applianceType}
            onChange={handleChange}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-secondary focus:ring-secondary"
            disabled={isSubmitting}
          >
            <option value="">Sélectionner un type...</option>
            <option value="stove">Cuisinière</option>
            <option value="oven">Four</option>
            <option value="induction_hob">Plaque induction</option>
            <option value="ceramic_hob">Plaque vitrocéramique</option>
            <option value="refrigerator">Réfrigérateur</option>
            <option value="freezer">Congélateur</option>
            <option value="washing_machine">Lave-linge</option>
            <option value="washer_dryer">Lave-linge séchant</option>
            <option value="dishwasher">Lave-vaisselle</option>
            <option value="dryer">Sèche-linge</option>
            <option value="wine_cellar">Cave à vin</option>
            <option value="hood">Hotte aspirante</option>
          </select>
        </div>

        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
          <div>
            <label className="block text-sm font-medium text-gray-700">
              Marque
            </label>
            <select
              name="brand"
              value={formData.brand}
              onChange={handleChange}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-secondary focus:ring-secondary"
              disabled={isSubmitting}
            >
              <option value="">Sélectionner une marque...</option>
              {BRANDS.map((brand) => (
                <option key={brand} value={brand}>
                  {brand}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">
              Modèle
            </label>
            <input
              type="text"
              name="model"
              value={formData.model}
              onChange={handleChange}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-secondary focus:ring-secondary"
              disabled={isSubmitting}
            />
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">
            Description du Problème
          </label>
          <textarea
            name="problemDescription"
            rows={4}
            value={formData.problemDescription}
            onChange={handleChange}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-secondary focus:ring-secondary"
            placeholder="Décrivez le problème en détail..."
            disabled={isSubmitting}
          />
        </div>

        <div className="flex justify-end">
          <button
            type="submit"
            disabled={isSubmitting}
            className="inline-flex justify-center items-center rounded-md border border-transparent bg-secondary py-2 px-4 text-sm font-medium text-white shadow-sm hover:bg-secondary-dark focus:outline-none focus:ring-2 focus:ring-secondary focus:ring-offset-2 disabled:opacity-50 space-x-2"
          >
            {isSubmitting ? (
              <>
                <Loader className="animate-spin h-4 w-4" />
                <span>Création en cours...</span>
              </>
            ) : (
              <>
                <Wrench className="h-4 w-4" />
                <span>{isOnline ? 'Créer le Dossier' : 'Créer en Mode Hors Ligne'}</span>
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  );
}