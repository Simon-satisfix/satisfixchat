import React, { useState, useEffect } from 'react';
import { useStore } from '../store/useStore';
import { MessageSquare, Send, Save } from 'lucide-react';
import { toast } from 'react-hot-toast';
import { db } from '../config/firebase';
import { doc, collection, updateDoc, getDocs, query, where, orderBy, serverTimestamp } from 'firebase/firestore';
import { useFirestoreDoc } from '../hooks/useFirestore';
import { Repair, ChatMessage } from '../types';

export function Assistant() {
  const [input, setInput] = useState('');
  const { chatHistory, addChatMessage, currentRepair, isOffline, user } = useStore();
  const [isLoading, setIsLoading] = useState(false);
  const [autoSaving, setAutoSaving] = useState(false);
  const { data: aiConfig, loading: configLoading, error: configError } = useFirestoreDoc('settings', 'ai');
  const [repairHistory, setRepairHistory] = useState<Repair[]>([]);

  // Initialize repair context when a new repair is created
  useEffect(() => {
    const initializeRepairContext = async () => {
      if (!currentRepair || chatHistory.length > 0 || !aiConfig?.apiKey) return;

      setIsLoading(true);
      try {
        const contextMessage = {
          role: 'system' as const,
          content: `Nouvelle réparation à analyser:
- Type d'appareil: ${currentRepair.applianceType}
- Marque: ${currentRepair.brand}
- Modèle: ${currentRepair.model}
- Description du problème: ${currentRepair.problemDescription}

${aiConfig.systemPrompt}

Veuillez analyser le problème et proposer un diagnostic initial.`
        };

        const response = await fetch('https://api.openai.com/v1/chat/completions', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${aiConfig.apiKey}`
          },
          body: JSON.stringify({
            model: 'gpt-4',
            messages: [contextMessage],
            temperature: 0.7,
            max_tokens: 1000
          })
        });

        if (!response.ok) {
          throw new Error('Erreur de communication avec l\'API OpenAI');
        }

        const data = await response.json();
        if (data.choices?.[0]?.message) {
          addChatMessage(contextMessage);
          addChatMessage(data.choices[0].message);

          // Update repair in Firestore
          const repairRef = doc(db, 'repairs', currentRepair.id);
          await updateDoc(repairRef, {
            aiConversation: [contextMessage, data.choices[0].message],
            status: 'in-progress',
            updatedAt: serverTimestamp()
          });
        }
      } catch (error) {
        console.error('Error initializing AI conversation:', error);
        toast.error('Erreur lors de l\'initialisation de la conversation avec l\'IA');
      } finally {
        setIsLoading(false);
      }
    };

    initializeRepairContext();
  }, [currentRepair, chatHistory.length, aiConfig, addChatMessage]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || !currentRepair) return;
    if (!aiConfig?.apiKey) {
      toast.error('L\'API OpenAI n\'est pas configurée');
      return;
    }

    if (isOffline) {
      toast.error('Mode hors ligne. Impossible de communiquer avec l\'assistant IA');
      return;
    }

    const userMessage = { role: 'user' as const, content: input.trim() };
    addChatMessage(userMessage);
    setIsLoading(true);
    setInput('');

    try {
      const response = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${aiConfig.apiKey}`
        },
        body: JSON.stringify({
          model: 'gpt-4',
          messages: [...chatHistory, userMessage],
          temperature: 0.7,
          max_tokens: 1000
        })
      });

      if (!response.ok) {
        throw new Error('Erreur de communication avec l\'API OpenAI');
      }

      const data = await response.json();
      if (data.choices?.[0]?.message) {
        const aiMessage = data.choices[0].message;
        addChatMessage(aiMessage);

        // Update repair in Firestore
        const repairRef = doc(db, 'repairs', currentRepair.id);
        await updateDoc(repairRef, {
          aiConversation: [...chatHistory, userMessage, aiMessage],
          updatedAt: serverTimestamp()
        });
      }
    } catch (error) {
      console.error('Error in AI communication:', error);
      toast.error('Erreur de communication avec l\'assistant IA');
      setInput(userMessage.content);
    } finally {
      setIsLoading(false);
    }
  };

  if (configLoading) {
    return (
      <div className="flex justify-center items-center min-h-[600px]">
        <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!currentRepair) {
    return (
      <div className="max-w-3xl mx-auto">
        <div className="bg-yellow-50 p-4 rounded-lg">
          <p className="text-yellow-700">Veuillez d'abord créer une nouvelle réparation</p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto">
      <div className="bg-white rounded-lg shadow-lg overflow-hidden">
        <div className="p-4 bg-primary">
          <h2 className="text-xl font-semibold text-white flex items-center">
            <MessageSquare className="mr-2" />
            Assistant de Réparation IA
          </h2>
          <div className="mt-2 text-sm text-white/80">
            {currentRepair.brand} {currentRepair.model} - {currentRepair.problemDescription}
          </div>
        </div>

        <div className="h-[600px] flex flex-col">
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {chatHistory.length === 0 ? (
              <div className="text-center text-gray-500 mt-8">
                <MessageSquare className="mx-auto h-12 w-12 mb-4" />
                <p>Initialisation de la conversation...</p>
              </div>
            ) : (
              chatHistory.map((message, index) => (
                <div
                  key={index}
                  className={`flex ${
                    message.role === 'user' ? 'justify-end' : 'justify-start'
                  }`}
                >
                  <div
                    className={`max-w-[80%] rounded-lg p-3 ${
                      message.role === 'user'
                        ? 'bg-primary text-white'
                        : message.role === 'system'
                        ? 'bg-gray-100 text-gray-700 font-medium'
                        : 'bg-gray-100 text-gray-900'
                    }`}
                  >
                    {message.content}
                  </div>
                </div>
              ))
            )}
            {isLoading && (
              <div className="flex justify-start">
                <div className="bg-gray-100 rounded-lg p-3 max-w-[80%]">
                  <div className="flex space-x-2">
                    <div className="w-2 h-2 bg-gray-500 rounded-full animate-bounce" />
                    <div className="w-2 h-2 bg-gray-500 rounded-full animate-bounce delay-100" />
                    <div className="w-2 h-2 bg-gray-500 rounded-full animate-bounce delay-200" />
                  </div>
                </div>
              </div>
            )}
          </div>

          <form onSubmit={handleSubmit} className="p-4 border-t">
            <div className="flex space-x-4">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder={isOffline ? "Mode hors ligne - Message indisponible" : "Votre message..."}
                className="flex-1 rounded-lg border-gray-300 focus:border-primary focus:ring-primary"
                disabled={isLoading || isOffline}
              />
              <button
                type="submit"
                disabled={isLoading || isOffline || !input.trim()}
                className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-primary hover:bg-primary-light focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary disabled:opacity-50"
              >
                <Send className="h-4 w-4" />
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}