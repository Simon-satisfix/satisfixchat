import React, { useState } from 'react';
import { doc, setDoc } from 'firebase/firestore';
import { db } from '../config/firebase';
import { toast } from 'react-hot-toast';
import { Bot, Key, X, Lock } from 'lucide-react';
import { useStore } from '../store/useStore';
import { useOnlineStatus } from '../hooks/useOnlineStatus';

interface AISettingsProps {
  onClose: () => void;
}

export function AISettings({ onClose }: AISettingsProps) {
  const { aiConfig, setAIConfig } = useStore();
  const [apiKey, setApiKey] = useState(aiConfig?.apiKey || '');
  const [systemPrompt, setSystemPrompt] = useState(aiConfig?.systemPrompt || '');
  const [saving, setSaving] = useState(false);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [password, setPassword] = useState('');
  const [authError, setAuthError] = useState('');
  const isOnline = useOnlineStatus();

  const handleAuth = (e: React.FormEvent) => {
    e.preventDefault();
    if (password === 'Admin123!') {
      setIsAuthenticated(true);
      setAuthError('');
    } else {
      setAuthError('Mot de passe incorrect');
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);

    const newConfig = { 
      apiKey: apiKey.trim(),
      systemPrompt: systemPrompt.trim(),
      updatedAt: new Date().toISOString()
    };

    try {
      // Always update local store
      setAIConfig(newConfig);

      // If online, sync with Firestore
      if (isOnline) {
        await setDoc(doc(db, 'settings', 'ai'), newConfig);
        toast.success('Paramètres IA mis à jour et synchronisés');
      } else {
        toast.success('Paramètres IA mis à jour localement');
        toast.warning('Les changements seront synchronisés une fois la connexion rétablie');
      }
      
      onClose();
    } catch (error) {
      console.error('Error saving settings:', error);
      toast.error('Erreur lors de la sauvegarde');
    } finally {
      setSaving(false);
    }
  };

  if (!isAuthenticated) {
    return (
      <div className="relative p-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center">
            <Lock className="h-6 w-6 text-secondary mr-2" />
            <h2 className="text-xl font-semibold">Accès Protégé</h2>
          </div>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-500">
            <X className="h-6 w-6" />
          </button>
        </div>

        <form onSubmit={handleAuth} className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Mot de passe administrateur
            </label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-secondary focus:border-secondary"
              placeholder="Entrez le mot de passe"
            />
            {authError && (
              <p className="mt-2 text-sm text-red-600">{authError}</p>
            )}
          </div>

          <div className="flex justify-end space-x-4">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50"
            >
              Annuler
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-secondary text-white rounded-md hover:bg-secondary-dark"
            >
              Accéder
            </button>
          </div>
        </form>
      </div>
    );
  }

  return (
    <div className="relative p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center">
          <Bot className="h-6 w-6 text-secondary mr-2" />
          <h2 className="text-xl font-semibold">Configuration de l'Assistant IA</h2>
        </div>
        <button onClick={onClose} className="text-gray-400 hover:text-gray-500">
          <X className="h-6 w-6" />
        </button>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            <div className="flex items-center">
              <Key className="h-4 w-4 mr-2" />
              Clé API OpenAI
            </div>
          </label>
          <input
            type="password"
            value={apiKey}
            onChange={(e) => setApiKey(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-secondary focus:border-secondary"
            placeholder="sk-..."
            disabled={saving}
          />
          <p className="mt-1 text-sm text-gray-500">
            Votre clé API OpenAI sera stockée de manière sécurisée
          </p>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Prompt Système
          </label>
          <textarea
            value={systemPrompt}
            onChange={(e) => setSystemPrompt(e.target.value)}
            rows={8}
            className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-secondary focus:border-secondary"
            placeholder="Vous êtes un expert en réparation d'appareils électroménagers..."
            disabled={saving}
          />
          <p className="mt-1 text-sm text-gray-500">
            Ce prompt définit le comportement et les connaissances de base de l'assistant
          </p>
        </div>

        <div className="flex justify-end space-x-4">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50"
            disabled={saving}
          >
            Annuler
          </button>
          <button
            type="submit"
            disabled={saving}
            className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-secondary hover:bg-secondary-dark focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-secondary disabled:opacity-50"
          >
            {saving ? (
              <>
                <span className="mr-2">Sauvegarde...</span>
                <div className="animate-spin h-4 w-4 border-2 border-white border-t-transparent rounded-full"></div>
              </>
            ) : (
              'Sauvegarder'
            )}
          </button>
        </div>
      </form>
    </div>
  );
}