import React, { useState } from 'react';
import { auth, db } from '../../config/firebase';
import { createUserWithEmailAndPassword } from 'firebase/auth';
import { doc, setDoc, getDoc } from 'firebase/firestore';
import { toast } from 'react-hot-toast';

const ADMIN_EMAIL = 'admin@aideareparation.com';
const ADMIN_PASSWORD = 'Admin123!';

export function InitAdmin() {
  const [initializing, setInitializing] = useState(false);

  const initializeAdmin = async () => {
    setInitializing(true);
    try {
      // Check if admin already exists
      const adminQuery = await getDoc(doc(db, 'users', 'admin'));
      if (adminQuery.exists()) {
        toast.error('Admin account already exists');
        return;
      }

      // Create admin account
      const { user } = await createUserWithEmailAndPassword(
        auth,
        ADMIN_EMAIL,
        ADMIN_PASSWORD
      );

      // Set admin data in Firestore
      await setDoc(doc(db, 'users', user.uid), {
        uid: user.uid,
        email: ADMIN_EMAIL,
        displayName: 'Administrateur',
        role: 'admin',
        approved: true,
        createdAt: new Date().toISOString()
      });

      toast.success('Admin account created successfully');
    } catch (error: any) {
      console.error('Error creating admin:', error);
      toast.error(error.message);
    } finally {
      setInitializing(false);
    }
  };

  return (
    <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50">
      <div className="bg-white p-6 rounded-lg shadow-xl">
        <h2 className="text-xl font-bold mb-4">Initialize Admin Account</h2>
        <p className="mb-4">
          This will create the default admin account with the following credentials:
          <br />
          Email: {ADMIN_EMAIL}
          <br />
          Password: {ADMIN_PASSWORD}
        </p>
        <button
          onClick={initializeAdmin}
          disabled={initializing}
          className="w-full bg-indigo-600 text-white py-2 px-4 rounded hover:bg-indigo-700 disabled:opacity-50"
        >
          {initializing ? 'Initializing...' : 'Initialize Admin Account'}
        </button>
      </div>
    </div>
  );
}