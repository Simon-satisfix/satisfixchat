import React, { useEffect, useState } from 'react';
import { db } from '../../config/firebase';
import { collection, query, where, getDocs } from 'firebase/firestore';
import { Repair, User } from '../../types';
import { Activity, User as UserIcon } from 'lucide-react';

interface UserHistoryProps {
  user: User;
}

export function UserHistory({ user }: UserHistoryProps) {
  const [repairs, setRepairs] = useState<Repair[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchUserRepairs = async () => {
      const q = query(
        collection(db, 'repairs'),
        where('technician', '==', user.displayName)
      );
      const querySnapshot = await getDocs(q);
      const repairsData = querySnapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      }) as Repair);
      setRepairs(repairsData);
      setLoading(false);
    };

    fetchUserRepairs();
  }, [user]);

  if (loading) {
    return <div className="flex justify-center p-8">
      <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-indigo-600"></div>
    </div>;
  }

  return (
    <div className="bg-white shadow rounded-lg p-6 mb-6">
      <div className="flex items-center mb-4">
        <UserIcon className="h-5 w-5 text-indigo-600 mr-2" />
        <h3 className="text-lg font-medium">{user.displayName}</h3>
      </div>
      
      <div className="border-t pt-4">
        <div className="flex items-center mb-3">
          <Activity className="h-5 w-5 text-gray-500 mr-2" />
          <h4 className="text-md font-medium">Activité récente</h4>
        </div>
        
        {repairs.length === 0 ? (
          <p className="text-gray-500 text-sm">Aucune réparation effectuée</p>
        ) : (
          <div className="space-y-4">
            {repairs.map((repair) => (
              <div key={repair.id} className="border-l-4 border-indigo-600 pl-4">
                <div className="flex justify-between items-start">
                  <div>
                    <p className="font-medium">
                      {repair.brand} {repair.model}
                    </p>
                    <p className="text-sm text-gray-600 mt-1">
                      {repair.problemDescription}
                    </p>
                  </div>
                  <span className={`px-2 py-1 text-xs font-semibold rounded-full ${
                    repair.status === 'completed'
                      ? 'bg-green-100 text-green-800'
                      : repair.status === 'in-progress'
                      ? 'bg-yellow-100 text-yellow-800'
                      : 'bg-gray-100 text-gray-800'
                  }`}>
                    {repair.status === 'completed' ? 'Terminé' : 
                     repair.status === 'in-progress' ? 'En cours' : 'En attente'}
                  </span>
                </div>
                <div className="mt-2 text-sm text-gray-500">
                  {new Date(repair.date).toLocaleDateString('fr-FR')}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}