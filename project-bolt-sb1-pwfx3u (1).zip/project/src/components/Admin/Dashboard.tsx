import React, { useEffect, useState } from 'react';
import { db } from '../../config/firebase';
import { collection, query, getDocs } from 'firebase/firestore';
import { User } from '../../types';
import { UserHistory } from './UserHistory';
import { AISettings } from './AISettings';
import { BarChart3, Users } from 'lucide-react';

export function AdminDashboard() {
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchUsers = async () => {
      const q = query(collection(db, 'users'));
      const querySnapshot = await getDocs(q);
      const usersData = querySnapshot.docs.map(doc => ({
        ...doc.data(),
        uid: doc.id
      }) as User);
      setUsers(usersData.filter(user => user.role === 'technician'));
      setLoading(false);
    };

    fetchUsers();
  }, []);

  if (loading) {
    return <div className="flex justify-center items-center min-h-screen">
      <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-indigo-600"></div>
    </div>;
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex items-center justify-between mb-8">
        <div className="flex items-center">
          <BarChart3 className="h-8 w-8 text-indigo-600 mr-3" />
          <h1 className="text-2xl font-bold text-gray-900">
            Tableau de Bord Administrateur
          </h1>
        </div>
        <div className="flex items-center bg-indigo-100 px-4 py-2 rounded-lg">
          <Users className="h-5 w-5 text-indigo-600 mr-2" />
          <span className="text-indigo-600 font-medium">
            {users.length} Techniciens
          </span>
        </div>
      </div>

      {/* Section Configuration IA */}
      <div className="mb-8">
        <AISettings />
      </div>

      {/* Section Historique des Techniciens */}
      <div className="grid grid-cols-1 gap-6">
        {users.map((user) => (
          <UserHistory key={user.uid} user={user} />
        ))}
      </div>
    </div>
  );
}