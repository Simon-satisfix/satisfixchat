import React, { useEffect, useState } from 'react';
import { db } from '../../config/firebase';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { toast } from 'react-hot-toast';
import { Bot, Key } from 'lucide-react';

export function AISettings() {
  const [apiKey, setApiKey] = useState('');
  const [systemPrompt, setSystemPrompt] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchSettings = async () => {
      const settingsDoc = await getDoc(doc(db, 'settings', 'ai'));
      if (settingsDoc.exists()) {
        const data = settingsDoc.data();
        setApiKey(data.apiKey || '');
        setSystemPrompt(data.systemPrompt || '');
      }
      setLoading(false);
    };

    fetchSettings();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await setDoc(doc(db, 'settings', 'ai'), {
        apiKey,
        systemPrompt,
        updatedAt: new Date().toISOString()
      });
      toast.success('Paramètres AI mis à jour');
    } catch (error) {
      toast.error('Erreur lors de la mise à jour');
    }
  };

  if (loading) {
    return <div className="flex justify-center p-8">
      <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-indigo-600"></div>
    </div>;
  }

  return (
    <div className="bg-white shadow rounded-lg p-6">
      <div className="flex items-center mb-6">
        <Bot className="h-6 w-6 text-indigo-600 mr-2" />
        <h2 className="text-xl font-semibold">Configuration de l'Assistant IA</h2>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            <div className="flex items-center">
              <Key className="h-4 w-4 mr-2" />
              Clé API OpenAI
            </div>
          </label>
          <input
            type="password"
            value={apiKey}
            onChange={(e) => setApiKey(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500"
            placeholder="sk-..."
          />
          <p className="mt-1 text-sm text-gray-500">
            Votre clé API OpenAI sera stockée de manière sécurisée
          </p>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Prompt Système
          </label>
          <textarea
            value={systemPrompt}
            onChange={(e) => setSystemPrompt(e.target.value)}
            rows={8}
            className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500"
            placeholder="Vous êtes un expert en réparation d'appareils électroménagers..."
          />
          <p className="mt-1 text-sm text-gray-500">
            Ce prompt définit le comportement et les connaissances de base de l'assistant
          </p>
        </div>

        <div className="flex justify-end">
          <button
            type="submit"
            className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
          >
            Sauvegarder les paramètres
          </button>
        </div>
      </form>
    </div>
  );
}