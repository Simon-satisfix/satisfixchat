import React, { useState } from 'react';
import { useStore } from '../store/useStore';
import { Search, Filter, MessageSquare } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export function RepairHistory() {
  const repairs = useStore((state) => state.repairs);
  const setCurrentRepair = useStore((state) => state.setCurrentRepair);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState('all');
  const navigate = useNavigate();

  const filteredRepairs = repairs.filter((repair) => {
    const matchesSearch =
      repair.problemDescription.toLowerCase().includes(searchTerm.toLowerCase()) ||
      repair.brand.toLowerCase().includes(searchTerm.toLowerCase()) ||
      repair.model.toLowerCase().includes(searchTerm.toLowerCase()) ||
      repair.clientName.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesFilter =
      filterType === 'all' || repair.applianceType === filterType;

    return matchesSearch && matchesFilter;
  });

  const handleRepairClick = (repair: typeof repairs[0]) => {
    setCurrentRepair(repair);
    navigate('/assistant');
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'pending':
        return 'En attente';
      case 'in-progress':
        return 'En cours';
      case 'completed':
        return 'Terminé';
      default:
        return status;
    }
  };

  const getApplianceTypeLabel = (type: string) => {
    switch (type) {
      case 'stove':
        return 'Cuisinière';
      case 'oven':
        return 'Four';
      case 'induction_hob':
        return 'Plaque induction';
      case 'ceramic_hob':
        return 'Plaque vitrocéramique';
      case 'refrigerator':
        return 'Réfrigérateur';
      case 'freezer':
        return 'Congélateur';
      case 'washing_machine':
        return 'Lave-linge';
      case 'washer_dryer':
        return 'Lave-linge séchant';
      case 'dishwasher':
        return 'Lave-vaisselle';
      case 'dryer':
        return 'Sèche-linge';
      case 'wine_cellar':
        return 'Cave à vin';
      case 'hood':
        return 'Hotte aspirante';
      default:
        return type;
    }
  };

  return (
    <div className="max-w-7xl mx-auto">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Historique des Réparations</h1>
        <p className="mt-2 text-sm text-gray-600">
          Consultez et recherchez les réparations passées
        </p>
      </div>

      <div className="mb-6 flex flex-col sm:flex-row gap-4">
        <div className="flex-1">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              placeholder="Rechercher des réparations..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 w-full rounded-md border-gray-300 shadow-sm focus:border-secondary focus:ring-secondary"
            />
          </div>
        </div>

        <div className="sm:w-64">
          <div className="relative">
            <Filter className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <select
              value={filterType}
              onChange={(e) => setFilterType(e.target.value)}
              className="pl-10 w-full rounded-md border-gray-300 shadow-sm focus:border-secondary focus:ring-secondary"
            >
              <option value="all">Tous les Types</option>
              <option value="stove">Cuisinière</option>
              <option value="oven">Four</option>
              <option value="induction_hob">Plaque induction</option>
              <option value="ceramic_hob">Plaque vitrocéramique</option>
              <option value="refrigerator">Réfrigérateur</option>
              <option value="freezer">Congélateur</option>
              <option value="washing_machine">Lave-linge</option>
              <option value="washer_dryer">Lave-linge séchant</option>
              <option value="dishwasher">Lave-vaisselle</option>
              <option value="dryer">Sèche-linge</option>
              <option value="wine_cellar">Cave à vin</option>
              <option value="hood">Hotte aspirante</option>
            </select>
          </div>
        </div>
      </div>

      <div className="bg-white shadow overflow-hidden sm:rounded-md">
        {filteredRepairs.length === 0 ? (
          <div className="text-center py-12">
            <p className="text-gray-500">Aucune réparation trouvée</p>
          </div>
        ) : (
          <ul className="divide-y divide-gray-200">
            {filteredRepairs.map((repair) => (
              <li 
                key={repair.id}
                onClick={() => handleRepairClick(repair)}
                className="hover:bg-gray-50 cursor-pointer transition-colors duration-150"
              >
                <div className="px-4 py-4 sm:px-6">
                  <div className="flex items-center justify-between">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <p className="text-sm font-medium text-secondary truncate">
                          {repair.clientName} - {repair.brand} {repair.model}
                        </p>
                        <div className="ml-2 flex-shrink-0">
                          <span
                            className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                              repair.status === 'completed'
                                ? 'bg-green-100 text-green-800'
                                : repair.status === 'in-progress'
                                ? 'bg-yellow-100 text-yellow-800'
                                : 'bg-gray-100 text-gray-800'
                            }`}
                          >
                            {getStatusLabel(repair.status)}
                          </span>
                        </div>
                      </div>
                      <div className="mt-2">
                        <p className="text-sm text-gray-600">
                          {repair.problemDescription}
                        </p>
                      </div>
                    </div>
                  </div>
                  <div className="mt-2 sm:flex sm:justify-between">
                    <div className="sm:flex">
                      <p className="flex items-center text-sm text-gray-500">
                        {getApplianceTypeLabel(repair.applianceType)}
                      </p>
                      <p className="mt-2 flex items-center text-sm text-gray-500 sm:mt-0 sm:ml-6">
                        Technicien: {repair.technicianEmail}
                      </p>
                      <MessageSquare className="ml-2 h-4 w-4 text-secondary" />
                    </div>
                    <div className="mt-2 flex items-center text-sm text-gray-500 sm:mt-0">
                      <p>
                        {new Date(repair.date).toLocaleDateString('fr-FR')}
                      </p>
                    </div>
                  </div>
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}