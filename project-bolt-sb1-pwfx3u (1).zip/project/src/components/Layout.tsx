import React, { useEffect, useState } from 'react';
import { Link, Outlet, useNavigate } from 'react-router-dom';
import { MessageSquare, Database, Menu, LogOut, WifiOff, Settings } from 'lucide-react';
import { useStore } from '../store/useStore';
import { auth } from '../config/firebase';
import { signOut } from 'firebase/auth';
import { toast } from 'react-hot-toast';
import { Modal } from './Modal';
import { AISettings } from './AISettings';

export function Layout() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const { user, isOffline, setOffline } = useStore();
  const navigate = useNavigate();

  useEffect(() => {
    const handleOnline = () => {
      setOffline(false);
      toast.success('Connexion rétablie');
    };

    const handleOffline = () => {
      setOffline(true);
      toast.error('Mode hors ligne');
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    setOffline(!navigator.onLine);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, [setOffline]);

  const handleLogout = async () => {
    try {
      await signOut(auth);
      toast.success('Déconnexion réussie');
      navigate('/login');
    } catch (error) {
      toast.error('Erreur lors de la déconnexion');
    }
  };

  const navigation = [
    { name: 'Nouvelle Réparation', href: '/', icon: MessageSquare },
    { name: 'Assistant IA', href: '/assistant', icon: MessageSquare },
    { name: 'Historique', href: '/history', icon: Database },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <nav className="bg-[#1a237e]">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex h-16 items-center justify-between">
            <div className="flex items-center">
              <Link to="/" className="flex items-center group">
                <div className="relative h-12 flex items-center justify-center transition-transform duration-300 group-hover:scale-105">
                  <img 
                    src="https://satisfix.fr/wp-content/uploads/2019/10/Satisfix-logo-blanc-vert-450-compressor.png" 
                    alt="Satisfix Logo" 
                    className="h-8 object-contain"
                  />
                </div>
              </Link>
            </div>

            {isOffline && (
              <div className="flex items-center px-3 py-1 rounded-full bg-red-500 text-white">
                <WifiOff className="h-4 w-4 mr-2" />
                <span className="text-sm">Hors ligne</span>
              </div>
            )}

            {/* Navigation Desktop */}
            <div className="hidden md:block">
              <div className="ml-10 flex items-baseline space-x-4">
                {navigation.map((item) => (
                  <Link
                    key={item.name}
                    to={item.href}
                    className="text-white hover:bg-[#283593] px-3 py-2 rounded-md text-sm font-medium"
                  >
                    <div className="flex items-center space-x-2">
                      <item.icon className="h-4 w-4" />
                      <span>{item.name}</span>
                    </div>
                  </Link>
                ))}
                <button
                  onClick={() => setIsSettingsOpen(true)}
                  className="text-white hover:bg-[#283593] px-3 py-2 rounded-md text-sm font-medium flex items-center space-x-2"
                >
                  <Settings className="h-4 w-4" />
                  <span>Configuration IA</span>
                </button>
                <button
                  onClick={handleLogout}
                  className="text-white hover:bg-[#283593] px-3 py-2 rounded-md text-sm font-medium flex items-center space-x-2"
                >
                  <LogOut className="h-4 w-4" />
                  <span>Déconnexion</span>
                </button>
              </div>
            </div>

            {/* Bouton menu mobile */}
            <div className="md:hidden">
              <button
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                className="text-white hover:bg-[#283593] p-2 rounded-md"
              >
                <Menu className="h-6 w-6" />
              </button>
            </div>
          </div>
        </div>

        {/* Navigation Mobile */}
        {isMobileMenuOpen && (
          <div className="md:hidden">
            <div className="space-y-1 px-2 pb-3 pt-2">
              {navigation.map((item) => (
                <Link
                  key={item.name}
                  to={item.href}
                  className="text-white hover:bg-[#283593] block px-3 py-2 rounded-md text-base font-medium"
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  <div className="flex items-center space-x-2">
                    <item.icon className="h-4 w-4" />
                    <span>{item.name}</span>
                  </div>
                </Link>
              ))}
              <button
                onClick={() => {
                  setIsMobileMenuOpen(false);
                  setIsSettingsOpen(true);
                }}
                className="text-white hover:bg-[#283593] w-full text-left px-3 py-2 rounded-md text-base font-medium flex items-center space-x-2"
              >
                <Settings className="h-4 w-4" />
                <span>Configuration IA</span>
              </button>
              <button
                onClick={handleLogout}
                className="text-white hover:bg-[#283593] w-full text-left px-3 py-2 rounded-md text-base font-medium flex items-center space-x-2"
              >
                <LogOut className="h-4 w-4" />
                <span>Déconnexion</span>
              </button>
            </div>
          </div>
        )}
      </nav>

      <main className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-6">
        <Outlet />
      </main>

      <Modal isOpen={isSettingsOpen} onClose={() => setIsSettingsOpen(false)}>
        <AISettings onClose={() => setIsSettingsOpen(false)} />
      </Modal>
    </div>
  );
}