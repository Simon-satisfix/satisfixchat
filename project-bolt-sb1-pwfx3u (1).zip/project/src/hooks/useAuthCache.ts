import { useState, useEffect } from 'react';
import { useStore } from '../store/useStore';

const CACHE_KEY = 'auth_user_cache';
const CACHE_DURATION = 24 * 60 * 60 * 1000; // 24 hours

interface CachedUser {
  data: any;
  timestamp: number;
}

export function useAuthCache() {
  const { setUser } = useStore();
  const [cache, setCache] = useState<Record<string, CachedUser>>(() => {
    try {
      const stored = localStorage.getItem(CACHE_KEY);
      return stored ? JSON.parse(stored) : {};
    } catch {
      return {};
    }
  });

  useEffect(() => {
    localStorage.setItem(CACHE_KEY, JSON.stringify(cache));
  }, [cache]);

  const getCachedUser = (uid: string) => {
    const cached = cache[uid];
    if (!cached) return null;

    const isExpired = Date.now() - cached.timestamp > CACHE_DURATION;
    if (isExpired) {
      const newCache = { ...cache };
      delete newCache[uid];
      setCache(newCache);
      return null;
    }

    return cached.data;
  };

  const cacheUser = (uid: string, userData: any) => {
    setCache(prev => ({
      ...prev,
      [uid]: {
        data: userData,
        timestamp: Date.now()
      }
    }));
  };

  const clearCache = () => {
    setCache({});
    localStorage.removeItem(CACHE_KEY);
  };

  return {
    getCachedUser,
    cacheUser,
    clearCache,
    setUser
  };
}