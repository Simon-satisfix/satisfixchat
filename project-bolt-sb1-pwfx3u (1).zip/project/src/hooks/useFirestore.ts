import { useState, useEffect } from 'react';
import { doc, getDoc, setDoc, DocumentData } from 'firebase/firestore';
import { db } from '../config/firebase';
import { useStore } from '../store/useStore';
import { toast } from 'react-hot-toast';

export function useFirestoreDoc(path: string, id: string) {
  const { aiConfig, setAIConfig } = useStore();
  const [loading, setLoading] = useState(!aiConfig);
  const [error, setError] = useState<Error | null>(null);
  const [offline, setOffline] = useState(!navigator.onLine);

  useEffect(() => {
    const handleOnline = () => setOffline(false);
    const handleOffline = () => setOffline(true);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  useEffect(() => {
    let mounted = true;
    let retryCount = 0;
    const maxRetries = 3;
    const retryDelay = 2000;

    const fetchData = async () => {
      // If we already have the config locally and we're offline, use the local version
      if (path === 'settings' && id === 'ai' && aiConfig && offline) {
        setLoading(false);
        return;
      }

      try {
        const docRef = doc(db, path, id);
        const docSnap = await getDoc(docRef);
        
        if (!mounted) return;

        if (docSnap.exists()) {
          const docData = docSnap.data();
          if (path === 'settings' && id === 'ai') {
            // Only update if data is different
            if (JSON.stringify(docData) !== JSON.stringify(aiConfig)) {
              setAIConfig(docData as { apiKey: string; systemPrompt: string });
            }
          }
          setError(null);
        } else if (path === 'settings' && id === 'ai') {
          // If we have a local config but no Firestore document, sync to Firestore
          if (aiConfig) {
            try {
              await setDoc(docRef, aiConfig);
            } catch (err) {
              console.warn('Failed to sync local config to Firestore:', err);
            }
          } else {
            // Set default config if none exists
            const defaultConfig = {
              apiKey: '',
              systemPrompt: 'Vous êtes un expert en réparation d\'appareils électroménagers...'
            };
            setAIConfig(defaultConfig);
            try {
              await setDoc(docRef, defaultConfig);
            } catch (err) {
              console.warn('Failed to save default config to Firestore:', err);
            }
          }
        }
        setLoading(false);
      } catch (err: any) {
        if (!mounted) return;

        if (offline) {
          setLoading(false);
          return;
        }

        console.error(`Error fetching ${path}/${id}:`, err);
        setError(err);
        
        if (retryCount < maxRetries && err.code === 'unavailable') {
          retryCount++;
          setTimeout(fetchData, retryDelay * retryCount);
        } else {
          setLoading(false);
        }
      }
    };

    fetchData();

    return () => {
      mounted = false;
    };
  }, [path, id, aiConfig, setAIConfig, offline]);

  // Always return the store version for AI config
  if (path === 'settings' && id === 'ai') {
    return { data: aiConfig, loading: false, error: null, offline };
  }

  return { data: null, loading, error, offline };
}