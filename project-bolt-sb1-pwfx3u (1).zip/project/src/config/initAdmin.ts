import { auth, db } from './firebase';
import { createUserWithEmailAndPassword } from 'firebase/auth';
import { doc, setDoc, getDoc } from 'firebase/firestore';

export async function initializeAdmin(email: string, password: string) {
  try {
    // Vérifier si l'admin existe déjà
    const adminDoc = await getDoc(doc(db, 'users', 'admin'));
    if (adminDoc.exists()) {
      console.log('Admin already exists');
      return;
    }

    // Créer le compte admin
    const { user } = await createUserWithEmailAndPassword(auth, email, password);
    
    // Définir les données admin
    await setDoc(doc(db, 'users', user.uid), {
      uid: user.uid,
      email,
      displayName: 'Administrateur',
      role: 'admin',
      approved: true,
      createdAt: new Date().toISOString()
    });

    console.log('Admin account created successfully');
  } catch (error) {
    console.error('Error creating admin:', error);
  }
}