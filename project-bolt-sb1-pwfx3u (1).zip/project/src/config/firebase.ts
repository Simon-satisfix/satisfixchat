// Re-export Firebase instances from the main initialization file
export { app, auth, db } from '../lib/firebase';