import { auth, db } from '../config/firebase';
import { createUserWithEmailAndPassword } from 'firebase/auth';
import { doc, setDoc } from 'firebase/firestore';

const ADMIN_EMAIL = 'simon.besnard@satisfix.fr';
const ADMIN_PASSWORD = 'Admin123!';

async function createAdminAccount() {
  try {
    // Create Firebase Auth account
    const { user } = await createUserWithEmailAndPassword(
      auth,
      ADMIN_EMAIL,
      ADMIN_PASSWORD
    );

    // Create admin document in Firestore
    await setDoc(doc(db, 'users', user.uid), {
      uid: user.uid,
      email: ADMIN_EMAIL,
      displayName: 'Simon Besnard',
      role: 'admin',
      approved: true,
      createdAt: new Date().toISOString()
    });

    console.log('Admin account created successfully');
    console.log('Email:', ADMIN_EMAIL);
    console.log('Password:', ADMIN_PASSWORD);
  } catch (error) {
    console.error('Error creating admin account:', error);
  }
}

createAdminAccount();