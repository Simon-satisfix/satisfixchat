import { initializeApp } from 'firebase/app';
import { getAuth, createUserWithEmailAndPassword } from 'firebase/auth';
import { getFirestore, doc, setDoc } from 'firebase/firestore';

const firebaseConfig = {
  apiKey: "AIzaSyAhIs1XSxnEBY9nerFxu8Xc-1ahhsMG1Os",
  authDomain: "aideareparation.firebaseapp.com",
  projectId: "aideareparation",
  storageBucket: "aideareparation.appspot.com",
  messagingSenderId: "240503897637",
  appId: "1:240503897637:web:1d989f02ec4224a38209cc"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

const ADMIN_EMAIL = 'admin@aideareparation.com';
const ADMIN_PASSWORD = 'Admin123!';

async function createAdminAccount() {
  try {
    // Create Firebase Auth account
    const { user } = await createUserWithEmailAndPassword(
      auth,
      ADMIN_EMAIL,
      ADMIN_PASSWORD
    );
    
    // Create admin document in Firestore
    await setDoc(doc(db, 'users', user.uid), {
      uid: user.uid,
      email: ADMIN_EMAIL,
      displayName: 'Administrateur',
      role: 'admin',
      approved: true,
      createdAt: new Date().toISOString()
    });

    console.log('Admin account created successfully');
    console.log('Email:', ADMIN_EMAIL);
    console.log('Password:', ADMIN_PASSWORD);
  } catch (error) {
    console.error('Error creating admin account:', error);
  }
}

createAdminAccount();