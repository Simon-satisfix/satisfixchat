import * as admin from 'firebase-admin';

const serviceAccount = {
  type: "service_account",
  project_id: "aidealareparation",
  private_key_id: "01e7804d75de23484341d38b1b3d44b1ea710407",
  private_key: "-----BEGIN PRIVATE KEY-----\nMIIEugIBADANBgkqhkiG9w0BAQEFAASCBKQwggSgAgEAAoIBAQDhmRfp+ztr2bSR\nSyEyVGcHXnR8lVTWj51jv6qZtH82zAx2ZRRM6FVV5JSQNpnJkdxUly3maPRA/phB\nbMq0qg+FYJT5EKj+o/pJHc9jjp63LZehrgcHuMsZXEsMiX8bCuIYFUy3Us5bCbHV\nZbwE3iHDXqoD4RLL3+MVv5+jtbOPd4V9453X84YiRqoc3Jz3VQXhbkP6DGJHQ7Rj\nIudaeTfUF6k4UJ8Vx2zNyoImA4AFM/un/LslfoQbw/9tF352u91nm9wkvDw8dH+p\nlO0UGLZTmpnTIlZm5skqWb0rxV5GTrfkIaspSRu5pY4KmvoJT6r1HCHy8KXbBlv/\npPGb18B3AgMBAAECgf4wiXnYL8ve392yNMuggX1rJmsycjd3rgZ/e/OSgA/aFEq8\nQnqIP/zsF43cB/kIPmX/Pmh/k7T5gEAUzsrHyYR5MONer7rP+k9f5M8Ns7RAgcaE\nTqJxFmIsW5McQxo8gnsd2iUT5DRu/oZk6kH8ae1fIx3g0iinR+dxhtO6pl7LgFWZ\nKVdibhNrF73CztiEI6B0IfABIk+agr6aVHySzqVvP+HyvlNfy4mTZsBTMGhQcYOe\ne2fifOhJk1UUobWP+f4uCJicShrO5bx18QcmE6zTcFoeb2uWj8JfhRmiVLAre2pJ\n+7A7Oi8YLe+HD0eGklj2vGULjB4MKZ90z6waMQKBgQD3P4mqZjdMqUJcbi4dwKyM\nPF5El4yMRCRiU8KPalt0F2YBwLdd6TG48ROlPADWPkA9qoVzfTKHQF29BALaXVgv\n02/1uotvGx/f6CR/uaguKJcRFcjCCm8vLXxnIPcajlJiDtm+vNqXlKzyTNvY79aD\neuYT7mxm3SMCuY3GJcNVJwKBgQDplV7hIci0X/rNGD3RVzT+cFJnpkBXiq7/lqnf\nEASosqSoqSOzKZncI3MW3LXLTALn9ATTh7hrOal91v6MJ6N9z1DpyZFAbDjavTDV\nBK9Zxlfcp35ej/0APCiStOMiAumk7N23/WpGpifDo1+3cwKzjUnEyCqPsRgJITMb\nfzhsMQKBgHZphKoKODPL4E9aKVXwf/LNuqwJFLPcsrwwtz5uRoxr5Fu0i107oKed\nNbZt7UyuFaAy+aTc8gUai4pJ0H/6MpD9J2K9S6gTiol2qXxOU0CAChGRqEteKe+j\nTjAp9o5OWSBDUn9p/RqZhtaofqX//3GKu4QSLPJ6uBjG+yJJ1aoDAoGBAN5o7dir\n1HF7WlFjHalwwfLrfGtY77brREn1aXYNyIHg58v4kReNKwVjc7h3G1qh27qErPvF\nJSJj2zEJP4KwU4n9luukk/ulkFUnA5IxTc3Lf+mISlk7/Qj2PyPBvOurnlD9gPgq\nAcGXgBFWRFNm3VGd3HnUpkH/vAUlaYZrEoxhAoGAUeWV+CohvA4XWOduDjNHJxIJ\nslW1awd/2gggttvhUJlHXLyNgRoGHvSl4U+egzhYXJ2B6LgxpSROviKibYaYMo1L\ntvtjqOpIt07oFk6/8t/WWp7DMgL81agwB0ij/lQnFgierxjRCqiBGXubBwRhbGvq\ncHQkt08FKGbzyTQH0dU=\n-----END PRIVATE KEY-----\n",
  client_email: "firebase-adminsdk-w67yv@aidealareparation.iam.gserviceaccount.com",
  client_id: "102998557434215849560",
  auth_uri: "https://accounts.google.com/o/oauth2/auth",
  token_uri: "https://oauth2.googleapis.com/token",
  auth_provider_x509_cert_url: "https://www.googleapis.com/oauth2/v1/certs",
  client_x509_cert_url: "https://www.googleapis.com/robot/v1/metadata/x509/firebase-adminsdk-w67yv%40aidealareparation.iam.gserviceaccount.com",
  universe_domain: "googleapis.com"
};

// Initialize Firebase Admin only once
if (!admin.apps.length) {
  try {
    admin.initializeApp({
      credential: admin.credential.cert(serviceAccount as admin.ServiceAccount)
    });
  } catch (error) {
    console.error('Firebase admin initialization error:', error);
  }
}

export const adminDb = admin.firestore();
export const adminAuth = admin.auth();