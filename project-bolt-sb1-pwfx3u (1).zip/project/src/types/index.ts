export interface Repair {
  id: string;
  applianceType: string;
  brand: string;
  model: string;
  serialNumber?: string; // Ajout du numéro de série
  problemDescription: string;
  diagnosis: string[];
  solution: string;
  parts?: {
    name: string;
    reference: string;
    quantity: number;
  }[]; // Structure plus détaillée pour les pièces
  clientName: string;
  clientPhone?: string; // Ajout du téléphone client
  clientEmail?: string; // Ajout de l'email client
  technicianEmail: string;
  status: 'pending' | 'in-progress' | 'completed' | 'cancelled';
  success: boolean;
  aiConversation: ChatMessage[];
  estimatedCost?: number; // Ajout du coût estimé
  finalCost?: number; // Ajout du coût final
  warranty?: boolean; // Ajout de l'information de garantie
  createdAt: string;
  updatedAt: string;
  completedAt?: string;
  scheduledDate?: string; // Date prévue de l'intervention
  duration?: number; // Durée de l'intervention en minutes
  location?: {
    address: string;
    city: string;
    postalCode: string;
  }; // Informations de localisation
  photos?: string[]; // URLs des photos
  priority: 'low' | 'medium' | 'high'; // Niveau de priorité
}

export interface ChatMessage {
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp?: string;
  id?: string;
}

export interface User {
  uid: string;
  email: string;
  displayName: string;
  role: 'technician' | 'admin';
  phone?: string;
  specialties?: string[]; // Spécialités du technicien
  certifications?: string[]; // Certifications du technicien
  availability?: {
    start: string;
    end: string;
    daysOff: string[];
  }; // Disponibilités du technicien
  createdAt: string;
  lastActive?: string;
  status: 'active' | 'inactive' | 'pending';
  approved: boolean;
  avatar?: string;
  zone?: string[]; // Zones d'intervention
}

export interface AIConfig {
  apiKey: string;
  systemPrompt: string;
  model: string;
  temperature: number;
  maxTokens: number;
  updatedAt: string;
  updatedBy: string;
}