/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        primary: {
          DEFAULT: '#1E1E4B', // bleu marine foncé
          light: '#2D2D71',
          dark: '#15152E',
        },
        secondary: {
          DEFAULT: '#6AB98C', // vert
          light: '#7DC99E',
          dark: '#569B73',
        },
        accent: {
          DEFAULT: '#FFD66B', // jaune
          light: '#FFE08F',
          dark: '#FFCC47',
        }
      },
      animation: {
        bounce: 'bounce 1s infinite',
      },
      keyframes: {
        bounce: {
          '0%, 100%': {
            transform: 'translateY(-25%)',
            animationTimingFunction: 'cubic-bezier(0.8, 0, 1, 1)',
          },
          '50%': {
            transform: 'translateY(0)',
            animationTimingFunction: 'cubic-bezier(0, 0, 0.2, 1)',
          },
        },
      },
    },
  },
  plugins: [],
};